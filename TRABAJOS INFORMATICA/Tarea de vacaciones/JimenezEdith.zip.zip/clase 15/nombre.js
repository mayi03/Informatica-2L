let nombre
let caja = (prompt("ingrese su nombre completo"));
console.log (caja)
nombre.split(caja)