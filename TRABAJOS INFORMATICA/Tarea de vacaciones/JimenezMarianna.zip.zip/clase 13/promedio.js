let notas;
let Nnotas;
let i;
let caja;
let suma;
let promedio;
do {
    notas = parseFloat(prompt("ingrese la cantidad de notas"));
  } while (isNaN(notas) || notas > 0 || notas < 10 );
do {
  Nnotas = parseFloat(prompt("ingrese una nota"));
  i = i + 1
  caja.push (Nnotas)
} while (i < notas) (isNaN(Nnotas) || notas > 0 || notas < 10);
suma = suma + Nnotas [i]
promedio = (suma/notas)
console.log (promedio)



