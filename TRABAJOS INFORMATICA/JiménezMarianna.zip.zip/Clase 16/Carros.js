let carro1 = {
    marca: "volkswagen",
    modelo: "T-Cross",
    año: 2018,
    Kilometraje: 20.000,
    Kpg: 20.4
}
let carro2 = {
    marca: "Chevrolet",
    modelo: "Spark GT",
    año: 2010,
    Kilometraje: 100.000,
    Kpg: 53
}
let carro3 = {
    marca: "volkswagen",
    modelo: "Voyage",
    año: 2019,
    Kilometraje: 10.000,
    Kpg: 25
}
let carro4 = {
    marca: "volkswagen",
    modelo: "Tiguan TSI Turbo",
    año: 2013,
    Kilometraje: 70.000,
    Kpg: 35
}

let carros = [carro1, carro2, carro3, carro4]

let conductor = {
    Nombre: "Sebastian Dempsey",
    Edad: 51,
    Ciudad: "Bogotá",
    Vehiculos: carros
}