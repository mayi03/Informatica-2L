let a = parseFloat(prompt("ingrese un numero"))
let b = parseFloat(prompt("ingrese un numero"))  
if (b == 0){
    alert("b es cero no es posible calcular la divisón y el modulo")
}
console.log(`la suma es: ${a + b}`);
console.log(`la resta es: ${a - b}`);
console.log(`la multiplicación es: ${a * b}`);
console.log(`la división es: ${a / b}`);
console.log(`El modulo es: ${a % b}`);

